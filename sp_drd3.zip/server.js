const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 5000;

// Povolení CORS
app.use(cors());

// Nastavení složky pro ukládání souborů do images
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadPath = path.join(__dirname, 'src/images');
        // Kontrola existence složky, pokud neexistuje, vytvoříme ji
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: function (req, file, cb) {
        cb(null, 'profile_image' + path.extname(file.originalname)); // Přejmenování souboru na "profile_image"
    }
});

const upload = multer({ storage: storage });

// Endpoint pro nahrání souboru
app.post('/Startovani', upload.single('file'), (req, res) => {
    if (req.file) {
        res.json({ success: true, filePath: `src/images/${req.file.filename}` });
    } else {
        res.status(400).json({ success: false, message: 'Soubor nebyl nahrán.' });
    }
});

// Slouží statické soubory ze složky "images"
app.use('/src/images', express.static(path.join(__dirname, 'src/images')));

app.listen(PORT, () => {
    console.log(`Server běží na portu ${PORT}`);
});