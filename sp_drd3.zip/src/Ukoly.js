import * as React from 'react';
import './App.css';
import {useEffect, useState} from "react";
import data from "./data/data.json";

export default function Ukoly() {

    const [quests, setQuests] = useState([]);
    const [newQuest, setNewQuest] = useState({ name: '', OZ: '' });

    const [actualNote, setActualNote] = useState("");



    useEffect(() => {

        setQuests(data.quests);
    }, []);


    return (
        <div style={{display: 'flex'}}>
            <div>
                <label className='quest_label'>
                    Quests:
                    <div className='quest_container'>
                        <table border="1" className='quest_table'>
                            {quests.map((quest, index) => (
                                <tr key={index}>
                                    <td className='quest_name'>
                                        <input
                                            className='quest_name_input'
                                            type="text"
                                            placeholder="Quest"
                                            value={quest.name}
                                            //onChange={(e) => updateQuestName(index, e.target.value)}
                                        />
                                    </td>
                                    <td className='quest_button'>
                                        <input
                                            className='quest_button_input'
                                            type="button"
                                            value='Notes'
                                            onClick={() => setActualNote(quest.note)}
                                        />
                                    </td>
                                </tr>
                            ))}
                            <tr>
                                <td className='quest_name'>
                                    <input className='quest_name_input' type="text" placeholder="Quest"/>
                                </td>
                                <td className='quest_button'>
                                    <input className='quest_button_input' type="button" value='Notes'/>
                                </td>
                            </tr>
                        </table>
                    </div>
                </label>
            </div>
            <div style={{width: '20vh'}}>

            </div>
            <div>
                <label className='console_label'>
                    Notes:
                    <div className='console scroll_bar_console'>
                        {actualNote}
                    </div>
                </label>
            </div>
        </div>
    )

}