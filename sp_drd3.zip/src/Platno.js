import * as React from 'react';
import './App.css';
import Postava from './Postava';
import Vybaveni from './Vybaveni';
import Inventar from './Inventar';
import Ukoly from './Ukoly';
import Action from './Action';

import data from './data/data.json';


import {useState} from "react";


export default function Platno({pristup}) {



    return (
        <div className='uvod'>
            {pristup === 0 && <h1>Character's diary</h1>}
            {pristup === 0 && <h2>{data.name}</h2>}

            {pristup === 1 && (
                <Postava />
            )}

            {pristup === 2 && (
                <Vybaveni />
            )}

            {pristup === 3 && (
                <Inventar />
            )}

            {pristup === 4 && (
                <Ukoly />
            )}

            {pristup === 5 && (
                <Action />
            )}

        </div>

    );
}