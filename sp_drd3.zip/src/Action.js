import * as React from 'react';
import './App.css';
import AttackAction from './AttackAction';
import ShootAction from './ShootAction';
import SpellAction from './SpellAction';
import CoverAction from './CoverAction';
import AbilityAction from './AbilityAction';
import SelectBoxAction from './SelectBoxAction';
import {useState} from "react";

export default function Action() {

    const [selectedOption, setSelectedOption] = useState('');

    const [selectedAbility, setSelectedAbility] = useState('');

    const [selectedWeaponClose, setSelectedWeaponClose] = useState('');

    const [selectedWeaponLong, setSelectedWeaponLong] = useState('');

    const [selectedWeaponForCover, setSelectedWeaponForCover] = useState('');



    return (
        <div>
            <SelectBoxAction selectedOption={selectedOption} setSelectedOption={setSelectedOption}/>

            {selectedOption === 'Attack' && (
                <AttackAction selectedWeaponClose={selectedWeaponClose} setSelectedWeaponClose={setSelectedWeaponClose}/>
            )}

            {selectedOption === 'Shoot' && (
                <ShootAction selectedWeaponLong={selectedWeaponLong} setSelectedWeaponLong={setSelectedWeaponLong}/>
            )}

            {selectedOption === 'Spell' && (
                <SpellAction />
            )}

            {selectedOption === 'Cover' && (
                <CoverAction selectedWeaponForCover={selectedWeaponForCover} setSelectedWeaponForCover={setSelectedWeaponForCover}/>
            )}

            {selectedOption === 'Using Ability' && (
                <AbilityAction selectedAbility={selectedAbility} setSelectedAbility={setSelectedAbility}/>
            )}

        </div>


    )

}