import * as React from 'react';
import './App.css';
import {useEffect, useState} from "react";

import data from './data/data.json';
import obr1 from './images/default_image.jpg';

export default function Postava() {

    const [name, setName] = useState(data.name);
    const [race, setRace] = useState(data.race);
    const [sex, setSex] = useState(data.sex);
    const [profession, setProfession] = useState(data.profession);
    const [level, setLevel] = useState(data.level);

    const [strength, setStrength] = useState(data.stats.strength);
    const [bonusStrength, setBonusStrength] = useState('');

    const [dexterity, setDexterity] = useState(data.stats.dexterity);
    const [bonusDexterity, setBonusDexterity] = useState('');

    const [endurance, setEndurance] = useState(data.stats.endurance);
    const [bonusEndurance, setBonusEndurance] = useState('');

    const [intelligence, setIntelligence] = useState(data.stats.intelligence);
    const [bonusIntelligence, setBonusIntelligence] = useState('');

    const [charisma, setCharisma] = useState(data.stats.charisma);
    const [bonusCharisma, setBonusCharisma] = useState('');


    const [health, setHealth] = useState(data.health);
    const [mags, setMags] = useState(data.mags);

    const [abilities, setAbilities] = useState([]);


    const [obr, setObr] = useState(obr1);


    const countBonus = (value, setBonus) => {
        const val = parseInt(value, 10);
        let bonus = '';
        if (val === 1) {
            bonus = '-5';
        } else if (val === 2 || val === 3) {
            bonus = '-4';
        } else if (val === 4 || val === 5) {
            bonus = '-3';
        } else if (val === 6 || val === 7) {
            bonus = '-2';
        } else if (val === 8 || val === 9) {
            bonus = '-1';
        } else if (val === 10 || val === 11 || val === 12) {
            bonus = '0';
        } else if (val === 13 || val === 14) {
            bonus = '+1';
        } else if (val === 15 || val === 16) {
            bonus = '+2';
        } else if (val === 17 || val === 18) {
            bonus = '+3';
        } else if (val === 19 || val === 20) {
            bonus = '+4';
        } else if (val === 21) {
            bonus = '+5';
        } else {
            bonus = 'ER';
        }
        setBonus(bonus);
    };

    const handleStatChange = (event, setStat, setBonus) => {
        const value = event.target.value;
        setStat(value);
        countBonus(value, setBonus);
    };

    useEffect(() => {
        countBonus(strength, setBonusStrength);
        countBonus(dexterity, setBonusDexterity);
        countBonus(endurance, setBonusEndurance);
        countBonus(intelligence, setBonusIntelligence);
        countBonus(charisma, setBonusCharisma);

        setAbilities(data.ability);

        const imageName = data.picture;
        import(`./images/${imageName}`)
            .then((image) => {
                setObr(image.default);
            })
            .catch((error) => {
                console.error("Error loading image:", error);
                setObr(obr1); // Fall back to default image if the import fails
            });
    }, []);

    async function updateFile(updatedData) {
        try {
            const response = await fetch('http://localhost:5002/Postava', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updatedData)
            });

            const data = await response.json();
            if (data.success) {
                console.log('Data úspěšně aktualizována.');
            } else {
                console.error('Chyba při aktualizaci dat:', data.error);
            }
        } catch (error) {
            console.error('Chyba při komunikaci se serverem:', error);
        }
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const updatedData = {
            name,
            race,
            sex,
            profession,
            level,
            health,
            mags,
            strength,
            dexterity,
            endurance,
            intelligence,
            charisma
        };
        updateFile(updatedData);
    };

    return (


        <div>

            <div style={{display: 'flex', marginTop: '-2.5vh', justifyContent: 'center'}}>
                <label>
                    Name:
                    <div>
                        <input
                            className='postava_inputs1'
                            placeholder='Name of character'
                            type="text"
                            value={name}
                            onChange={(e) => {setName(e.target.value); handleSubmit(e)}}
                            onMouseMove={(e) => handleSubmit(e)}
                        />
                    </div>
                </label>

                <label>
                    Race:
                    <div>
                        <input
                            className='postava_inputs1'
                            placeholder='Race'
                            type="text"
                            value={race}
                            onChange={(e) => setRace(e.target.value)}
                            onMouseMove={(e) => handleSubmit(e)}
                        />
                    </div>
                </label>

                <label>
                    Sex:
                    <div>
                        <input
                            className='postava_inputs1'
                            placeholder='Sex'
                            type="text"
                            value={sex}
                            onChange={(e) => setSex(e.target.value)}
                            onMouseMove={(e) => handleSubmit(e)}
                        />
                    </div>
                </label>

                <label>
                    Profession:
                    <div>
                        <input
                            className='postava_inputs1'
                            placeholder='Profession'
                            type="text"
                            value={profession}
                            onChange={(e) => setProfession(e.target.value)}
                            onMouseMove={(e) => handleSubmit(e)}
                        />
                    </div>
                </label>

                <label>
                    Level:
                    <div>
                        <input
                            className='postava_inputs1'
                            placeholder='Level'
                            type="number"
                            style={{paddingLeft: '3vh'}}
                            value={level}
                            onChange={(e) => setLevel(e.target.value)}
                            onMouseMove={(e) => handleSubmit(e)}
                        />
                    </div>
                </label>

            </div>

            <div style={{display: 'flex'}}>
                <div className='vzhled_profilu'  style={{backgroundImage: 'url(' + obr + ')'}}>
                </div>

                <div className='zivoty_a_magy'>
                    <div>
                        <label>
                            Health
                            <input
                                className='health'
                                placeholder='Health'
                                type="number"
                                value={health}
                                onChange={(e) => setHealth(e.target.value)}
                                onMouseMove={(e) => handleSubmit(e)}
                            />
                        </label>
                    </div>


                    <br/>
                    <div>
                        <label>
                            Mags
                            <input
                                className='mags'
                                placeholder='Mags'
                                type="number"
                                value={mags}
                                onChange={(e) => setMags(e.target.value)}
                                onMouseMove={(e) => handleSubmit(e)}
                            />
                        </label>
                    </div>

                </div>

                <div>
                    <table className='basicStats'>
                        <tr>
                            <td className='name_of_stats'>Stregth</td>
                            <td className='values_of_stats'><input className='stats_input' type="number"
                                                                   value={strength}
                                                                   onChange={(e) => handleStatChange(e, setStrength, setBonusStrength)}
                                                                   onMouseMove={(e) => handleSubmit(e)}
                            />
                            </td>
                            <td className='values_of_stats'><input className='stats_input' type="text"
                                                                   value={bonusStrength} readOnly/></td>
                        </tr>
                        <tr>
                            <td className='name_of_stats'>Dexterity</td>
                            <td className='values_of_stats'><input className='stats_input' type="number"
                                                                   value={dexterity}
                                                                   onChange={(e) => handleStatChange(e, setDexterity, setBonusDexterity)}
                                                                   onMouseMove={(e) => handleSubmit(e)}
                            />
                            </td>
                            <td className='values_of_stats'><input className='stats_input' type="text"
                                                                   value={bonusDexterity} readOnly/></td>
                        </tr>
                        <tr>
                            <td className='name_of_stats'>Endurance</td>
                            <td className='values_of_stats'><input className='stats_input' type="number"
                                                                   value={endurance}
                                                                   onChange={(e) => handleStatChange(e, setEndurance, setBonusEndurance)}
                                                                   onMouseMove={(e) => handleSubmit(e)}
                            />
                            </td>
                            <td className='values_of_stats'><input className='stats_input' type="text"
                                                                   value={bonusEndurance} readOnly/></td>
                        </tr>
                        <tr>
                            <td className='name_of_stats'>Inteligence</td>
                            <td className='values_of_stats'><input className='stats_input' type="number"
                                                                   value={intelligence}
                                                                   onChange={(e) => handleStatChange(e, setIntelligence, setBonusIntelligence)}
                                                                   onMouseMove={(e) => handleSubmit(e)}
                            />
                            </td>
                            <td className='values_of_stats'><input className='stats_input' type="text"
                                                                   value={bonusIntelligence} readOnly/></td>
                        </tr>
                        <tr>
                            <td className='name_of_stats'>Charisma</td>
                            <td className='values_of_stats'><input className='stats_input' type="number"
                                                                   value={charisma}
                                                                   onChange={(e) => handleStatChange(e, setCharisma, setBonusCharisma)}
                                                                   onMouseMove={(e) => handleSubmit(e)}
                            />
                            </td>
                            <td className='values_of_stats'><input className='stats_input' type="text"
                                                                   value={bonusCharisma} readOnly/></td>
                        </tr>
                    </table>

                    <div style={{height: '2vh'}}>

                    </div>

                    <label className='abilities'>
                        Abilities:
                        <div className="abilities_table_container">
                            <table border="1" className='abilities_table'>
                                {abilities.map((ability, index) => (
                                    <tr key={index}>
                                        <td className='ability_row'>
                                            <input
                                                className='ability_input'
                                                type="text"
                                                placeholder="New ability"
                                                value={ability.name}
                                                //onChange={(e) => updateAbility(index, 'name', e.target.value)}
                                            />
                                        </td>
                                        <td className='ability_stat'>
                                            <input
                                                className='ability_stat_input'
                                                type="number"
                                                placeholder="Trap"
                                                value={ability.trap}
                                                //onChange={(e) => updateAbility(index, 'trap', e.target.value)}
                                            />
                                        </td>
                                        <td className='ability_stat_sign'>
                                            <input
                                                className='ability_stat_sign_input'
                                                type="text"
                                                placeholder="Stat"
                                                value={ability.stat}
                                                //onChange={(e) => updateAbility(index, 'stat', e.target.value)}
                                            />
                                        </td>
                                    </tr>
                                ))}
                                <tr>
                                    <td className='ability_row'>
                                        <input className='ability_input' type="text" placeholder="New ability"/>
                                    </td>
                                    <td className='ability_stat'>
                                        <input className='ability_stat_input' type="text" placeholder="Trap"/>
                                    </td>
                                    <td className='ability_stat_sign'>
                                        <input className='ability_stat_sign_input' type="text" placeholder="Stat"/>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </label>

                </div>
            </div>
        </div>
    )

}