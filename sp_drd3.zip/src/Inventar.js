import * as React from 'react';
import './App.css';
import {useEffect, useState} from "react";
import data from './data/data.json';

export default function Inventar() {

    const [gold, setGold] = useState(data.gold);
    const [silver, setSilver] = useState(data.silver);
    const [cooper, setCopper] = useState(data.cooper);


    const [inventory, setInventory] = useState([]);
    const [newArmor, setNewArmor] = useState({ name: '', OZ: '' });

    useEffect(() => {

        setInventory(data.inventory);
    }, []);

    async function updateFile(updatedData) {
        try {
            const response = await fetch('http://localhost:5003/Inventar', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updatedData)
            });

            const data = await response.json();
            if (data.success) {
                console.log('Data úspěšně aktualizována.');
            } else {
                console.error('Chyba při aktualizaci dat:', data.error);
            }
        } catch (error) {
            console.error('Chyba při komunikaci se serverem:', error);
        }
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const updatedData = {
            gold,
            silver,
            cooper
        };
        updateFile(updatedData);
    };


    return (
        <div style={{display: 'flex'}}>
            <div className='penize'>
                    <label>
                        Gold:
                    </label>
                        <input
                            className='coins'
                            placeholder='Golds'
                            type="number"
                            value={gold}
                            onChange={(e) => setGold(e.target.value)}
                            onMouseMove={(e) => handleSubmit(e)}
                        />


                    <label>
                        Silver:
                    </label>
                        <input
                            className='coins'
                            placeholder='Silver'
                            type="number"
                            value={silver}
                            onChange={(e) => setSilver(e.target.value)}
                            onMouseMove={(e) => handleSubmit(e)}
                        />


                    <label>
                        Copper:
                    </label>
                        <input
                            className='coins'
                            placeholder='Copper'
                            type="number"
                            value={cooper}
                            onChange={(e) => setCopper(e.target.value)}
                            onMouseMove={(e) => handleSubmit(e)}
                        />

            </div>

            <div style={{width: '20vh'}}>

            </div>
            <div>
                <label className='inventory_label'>
                    Inventory:
                    <div className='inventory_container'>
                        <table border="1" className='inventory_table'>
                            {inventory.map((item, index) => (
                                <tr key={index}>
                                    <td className='inventory_name'>
                                        <input
                                            className='inventory_name_input'
                                            type="text"
                                            placeholder="Thing"
                                            value={item.name}
                                            //onChange={(e) => updateItem(index, 'name', e.target.value)}
                                        />
                                    </td>
                                    <td className='inventory_stat'>
                                        <input
                                            className='inventory_stat_input'
                                            type="number"
                                            placeholder="AM"
                                            value={item.amount}
                                            //onChange={(e) => updateItem(index, 'amount', e.target.value)}
                                        />
                                    </td>
                                </tr>
                            ))}
                            <tr>
                                <td className='inventory_name'>
                                    <input className='inventory_name_input' type="text" placeholder="Thing"/>
                                </td>
                                <td className='inventory_stat'>
                                    <input className='inventory_stat_input' type="text" placeholder="AM"/>
                                </td>
                            </tr>
                        </table>
                    </div>
                </label>
            </div>
        </div>
    )

}