import * as React from 'react';
import './App.css';
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import Box from '@mui/material/Box';

import Startovani from './Startovani';
import Platno from './Platno'
import {useState} from "react";

export default function App() {

    const [pristup, setPristup] = useState(-1);

    return (
        <div className='App'>
            {pristup === -1 && (
                <Startovani setPristup={setPristup}/>
            )}

            {pristup !== -1 && (

            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    '& > *': {
                        m: 1,
                    },
                }}
            >
                <ButtonGroup variant="outlined" aria-label="Basic button group">
                    <Button style={{color: 'darkred',
                        border: '0.4vh solid darkred',
                        fontFamily: 'Papyrus',
                        backgroundColor: pristup === 1 ? '' : 'white',
                        fontWeight: 'bold',
                        fontSize: '2vh',
                        width: '24vh',
                        height: '6vh'}}
                        onClick={e => setPristup(1)}>Character</Button>
                    <Button style={{color: 'darkred',
                        border: '0.4vh solid darkred',
                        fontFamily: 'Papyrus',
                        backgroundColor: pristup === 2 ? '' : 'white',
                        fontWeight: 'bold',
                        fontSize: '2vh',
                        width: '24vh',
                        height: '6vh'}}
                            onClick={e => setPristup(2)}>Equipment</Button>
                    <Button style={{color: 'darkred',
                        border: '0.4vh solid darkred',
                        fontFamily: 'Papyrus',
                        backgroundColor: pristup === 3 ? '' : 'white',
                        fontWeight: 'bold',
                        fontSize: '2vh',
                        width: '24vh',
                        height: '6vh'}}
                            onClick={e => setPristup(3)}>Inventory</Button>
                    <Button style={{color: 'darkred',
                        border: '0.4vh solid darkred',
                        fontFamily: 'Papyrus',
                        backgroundColor: pristup === 4 ? '' : 'white',
                        fontWeight: 'bold',
                        fontSize: '2vh',
                        width: '24vh',
                        height: '6vh'}}
                            onClick={e => setPristup(4)}>Quests</Button>
                    <Button style={{color: 'darkred',
                        border: '0.4vh solid darkred',
                        fontFamily: 'Papyrus',
                        backgroundColor: pristup === 5 ? '' : 'white',
                        fontWeight: 'bold',
                        fontSize: '2vh',
                        width: '24vh',
                        height: '6vh'}}
                            onClick={e => setPristup(5)}>Action</Button>
                </ButtonGroup>
            </Box>
            )}

            <Platno pristup={pristup}/>
        </div>

    );
}