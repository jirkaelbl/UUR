import React, { useState } from 'react';
import './App.css';

const SelectBoxAction = ({selectedOption, setSelectedOption}) => {

    const handleSelectChange = (event) => {
        setSelectedOption(event.target.value);
    };

    return (
        <div>
            <label className='select_action_label'>
                Choose the action:
                <br/>
                <select
                    className='select_action'
                    id="action-select"
                    value={selectedOption}
                    onChange={handleSelectChange}
                >
                    <option value="">--Choose--</option>
                    <option value="Attack">Attack</option>
                    <option value="Shoot">Shoot</option>
                    <option value="Spell">Spell</option>
                    <option value="Cover">Cover</option>
                    <option value="Using Ability">Using Ability</option>
                </select>
            </label>
        </div>
    );
};

export default SelectBoxAction;
