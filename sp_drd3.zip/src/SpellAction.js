import * as React from 'react';
import './App.css';
import SelectBoxWeaponClose from "./SelectBoxWeaponClose";


export default function SpellAction() {


    return (
        <div>



            <div>
                <div>
                    <div className='weapon_close_actioner' style={{display: 'flex'}}>

                        <label>
                            Inteligence:
                            <br/>
                            <input
                                className='spell_stat'
                                value='+3'
                                type="text"
                            />
                        </label>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            Throw:
                            <br/>
                            <input
                                className='spell_throw'
                                placeholder='Throw'
                                type="number"
                            />
                        </label>

                    </div>
                    <div style={{marginTop: '10vh'}}>
                        <label style={{fontSize: '5vh'}}>
                            Result:
                            <br/>
                            <input
                                className='weapon_close_result'
                                value='10'
                                type="text"
                            />
                        </label>
                    </div>
                </div>
            </div>


        </div>


    )

}