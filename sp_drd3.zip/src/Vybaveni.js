import * as React from 'react';
import './App.css';
import data from './data/data.json';
import {useEffect, useState} from "react";

export default function Vybaveni() {

    const [weapons, setWeapons] = useState([]);
    const [newWeapon, setNewWeapon] = useState({ name: '', UC: '', utoc: '', OZ: '' });

    const [weaponsL, setWeaponsL] = useState([]);
    const [newWeaponL, setNewWeaponL] = useState({ name: '', UC: '', utoc: '', M: '', S: '', V: '' });

    const [armors, setArmors] = useState([]);
    const [newArmor, setNewArmor] = useState({ name: '', OZ: '' });

    useEffect(() => {

        setWeapons(data.weapon_face_to_face);
        setWeaponsL(data.weapon_long_distance);
        setArmors(data.armor);


    }, []);


    return (
        <div className='vybaveni'>
            <div style={{display: "flex"}}>
                <label>
                    Attact number - fight face to face:
                    <div className="face_to_face_container">
                        <table border="1" className='face_to_face_table'>
                            <tbody>
                            {weapons.map((weapon, index) => (
                                <tr key={index}>
                                    <td className='weapon_name'>
                                        <input
                                            className='weapon_name_input'
                                            type="text"
                                            placeholder="Name of weapon"
                                            value={weapon.name}
                                            //onChange={(e) => updateWeapon(index, 'name', e.target.value)}
                                        />
                                    </td>
                                    <td className='weapon_stat'>
                                        <input
                                            className='weapon_stat_input'
                                            type="text"
                                            placeholder="UC"
                                            value={weapon.UC}
                                            //onChange={(e) => updateWeapon(index, 'UC', e.target.value)}
                                        />
                                    </td>
                                    <td className='weapon_stat'>
                                        <input
                                            className='weapon_stat_input'
                                            type="text"
                                            placeholder="utoc"
                                            value={weapon.utoc}
                                            //onChange={(e) => updateWeapon(index, 'utoc', e.target.value)}
                                        />
                                    </td>
                                    <td className='weapon_stat'>
                                        <input
                                            className='weapon_stat_input'
                                            type="text"
                                            placeholder="OZ"
                                            value={weapon.OZ}
                                            //onChange={(e) => updateWeapon(index, 'OZ', e.target.value)}
                                        />
                                    </td>
                                </tr>
                            ))}
                            <tr>
                                <td className='weapon_name'>
                                    <input
                                        className='weapon_name_input'
                                        type="text"
                                        placeholder="New Weapon"
                                        value={newWeapon.name}
                                        //onChange={(e) => handleNewWeaponChange('name', e.target.value)}
                                    />
                                </td>
                                <td className='weapon_stat'>
                                    <input
                                        className='weapon_stat_input'
                                        type="text"
                                        placeholder="UC"
                                        value={newWeapon.UC}
                                        //onChange={(e) => handleNewWeaponChange('UC', e.target.value)}
                                    />
                                </td>
                                <td className='weapon_stat'>
                                    <input
                                        className='weapon_stat_input'
                                        type="text"
                                        placeholder="utoc"
                                        value={newWeapon.utoc}
                                        //onChange={(e) => handleNewWeaponChange('utoc', e.target.value)}
                                    />
                                </td>
                                <td className='weapon_stat'>
                                    <input
                                        className='weapon_stat_input'
                                        type="text"
                                        placeholder="OZ"
                                        value={newWeapon.OZ}
                                        //onChange={(e) => handleNewWeaponChange('OZ', e.target.value)}
                                    />
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </label>

                <div className='mezera'></div>

                <label>
                    Attact number - shooting match:
                    <div className="face_to_face_container">
                        <table border="1" className='face_to_face_table'>
                            <tbody>
                            {weaponsL.map((weapon, index) => (
                                <tr key={index}>
                                    <td className='weapon_name'>
                                        <input
                                            className='weapon_name_input'
                                            type="text"
                                            placeholder="Name of weapon"
                                            value={weapon.name}
                                            //onChange={(e) => updateWeapon(index, 'name', e.target.value)}
                                        />
                                    </td>
                                    <td className='weapon_stat'>
                                        <input
                                            className='weapon_stat_input'
                                            type="text"
                                            placeholder="UC"
                                            value={weapon.UC}
                                            //onChange={(e) => updateWeapon(index, 'UC', e.target.value)}
                                        />
                                    </td>
                                    <td className='weapon_stat'>
                                        <input
                                            className='weapon_stat_input'
                                            type="text"
                                            placeholder="utoc"
                                            value={weapon.utoc}
                                            //onChange={(e) => updateWeapon(index, 'utoc', e.target.value)}
                                        />
                                    </td>
                                    <td className='weapon_stat'>
                                        <input
                                            className='weapon_stat_input'
                                            type="text"
                                            placeholder="M"
                                            value={weapon.M}
                                            //onChange={(e) => updateWeapon(index, 'M', e.target.value)}
                                        />
                                    </td>
                                    <td className='weapon_stat'>
                                        <input
                                            className='weapon_stat_input'
                                            type="text"
                                            placeholder="S"
                                            value={weapon.S}
                                            //onChange={(e) => updateWeapon(index, 'S', e.target.value)}
                                        />
                                    </td>
                                    <td className='weapon_stat'>
                                        <input
                                            className='weapon_stat_input'
                                            type="text"
                                            placeholder="V"
                                            value={weapon.V}
                                            //onChange={(e) => updateWeapon(index, 'V', e.target.value)}
                                        />
                                    </td>
                                </tr>
                            ))}
                            <tr>
                                <td className='weapon_name'>
                                    <input
                                        className='weapon_name_input'
                                        type="text"
                                        placeholder="New Weapon"
                                        value={newWeapon.name}
                                        //onChange={(e) => handleNewWeaponChange('name', e.target.value)}
                                    />
                                </td>
                                <td className='weapon_stat'>
                                    <input
                                        className='weapon_stat_input'
                                        type="text"
                                        placeholder="UC"
                                        value={newWeapon.UC}
                                        //onChange={(e) => handleNewWeaponChange('UC', e.target.value)}
                                    />
                                </td>
                                <td className='weapon_stat'>
                                    <input
                                        className='weapon_stat_input'
                                        type="text"
                                        placeholder="utoc"
                                        value={newWeapon.utoc}
                                        //onChange={(e) => handleNewWeaponChange('utoc', e.target.value)}
                                    />
                                </td>
                                <td className='weapon_stat'>
                                    <input
                                        className='weapon_stat_input'
                                        type="text"
                                        placeholder="M"
                                        value={newWeapon.M}
                                        //onChange={(e) => handleNewWeaponChange('M', e.target.value)}
                                    />
                                </td>
                                <td className='weapon_stat'>
                                    <input
                                        className='weapon_stat_input'
                                        type="text"
                                        placeholder="S"
                                        value={newWeapon.S}
                                        //onChange={(e) => handleNewWeaponChange('S', e.target.value)}
                                    />
                                </td>
                                <td className='weapon_stat'>
                                    <input
                                        className='weapon_stat_input'
                                        type="text"
                                        placeholder="V"
                                        value={newWeapon.V}
                                        //onChange={(e) => handleNewWeaponChange('V', e.target.value)}
                                    />
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </label>
            </div>
            <div className='mezera_height'>

            </div>
            <div>
                <label style={{marginTop: '3vh'}}>
                    Armor:
                    <div>
                        <table border="1" className='armor_table'>
                            <tbody>
                            {armors.map((armor, index) => (
                                <tr key={index}>
                                    <td className='armor_name'>
                                        <input
                                            className='armor_name_input'
                                            type="text"
                                            placeholder="Name of armor"
                                            value={armor.name}
                                            //onChange={(e) => updateArmor(index, 'name', e.target.value)}
                                        />
                                    </td>
                                    <td className='armor_stat'>
                                        <input
                                            className='armor_stat_input'
                                            type="number"
                                            placeholder="OZ"
                                            value={armor.OZ}
                                            //onChange={(e) => updateArmor(index, 'OZ', e.target.value)}
                                        />
                                    </td>
                                </tr>
                            ))}
                            <tr>
                                <td className='armor_name'>
                                    <input
                                        className='armor_name_input'
                                        type="text"
                                        placeholder="New Armor"
                                        value={newArmor.name}
                                        //onChange={(e) => handleNewArmorChange('name', e.target.value)}
                                    />
                                </td>
                                <td className='armor_stat'>
                                    <input
                                        className='armor_stat_input'
                                        type="text"
                                        placeholder="OZ"
                                        value={newArmor.OZ}
                                        //onChange={(e) => handleNewArmorChange('OZ', e.target.value)}
                                    />
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </label>
            </div>

        </div>
    )

}