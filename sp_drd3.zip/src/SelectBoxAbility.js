import React, { useState } from 'react';
import './App.css';

const SelectBoxAbility = ({selectedAbility, setSelectedAbility}) => {

    const handleSelectChange = (event) => {
        setSelectedAbility(event.target.value);
    };

    return (
        <div>
            <label className='select_weapon_close_label'>
                Choose the ability:
                <br/>
                <select
                    className='select_weapon_close'
                    id="abilty-select"
                    value={selectedAbility}
                    onChange={handleSelectChange}
                >
                    <option value="">--Choose--</option>
                    <option value="Ability1">Ability1</option>
                    <option value="Ability2">Ability2</option>
                    <option value="Ability3">Ability3</option>
                </select>
            </label>
        </div>
    );
};

export default SelectBoxAbility;
