import * as React from 'react';
import './App.css';
import SelectBoxAbility from './SelectBoxAbility';

export default function AbilityAction({selectedAbility, setSelectedAbility}) {

    return (
                <div>
                    <div className='abilities_actioner' style={{display: 'flex'}}>
                        <SelectBoxAbility selectedAbility={selectedAbility} setSelectedAbility={setSelectedAbility}/>

                        <div style={{width: '20vh'}}>

                        </div>

                        <label className='ability_trap_label'>
                            Trap:
                            <br/>
                            <input
                                className='ability_trap'
                                value='10'
                                type="text"
                            />
                        </label>

                        <div style={{width: '20vh'}}>

                        </div>

                        <label>
                            Stat:
                            <br/>
                            <input
                                className='ability_stat'
                                placeholder='Value of stat'
                                type="text"
                            />
                        </label>

                        <div style={{width: '20vh'}}>

                        </div>

                        <label>
                            Throw:
                            <br/>
                            <input
                                className='ability_throw'
                                placeholder='Throw'
                                type="number"
                            />
                        </label>
                    </div>
                    <div style={{marginTop: '10vh'}}>
                        <label style={{fontSize: '5vh'}}>
                            Result:
                            <br/>
                            <input
                                className='ability_result'
                                value='10'
                                type="text"
                            />
                        </label>
                    </div>
                </div>
    )

}