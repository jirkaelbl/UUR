import React, { useState } from 'react';
import './App.css';

const SelectBoxAbility = ({selectedWeaponClose, setSelectedWeaponClose}) => {

    const handleSelectChange = (event) => {
        setSelectedWeaponClose(event.target.value);
    };

    return (
        <div>
            <label className='select_weapon_label'>
                Choose the weapon:
                <br/>
                <select
                    className='select_ability'
                    id="weapon-select"
                    value={selectedWeaponClose}
                    onChange={handleSelectChange}
                >
                    <option value="">--Choose--</option>
                    <option value="Weapon1">Weapon1</option>
                    <option value="Weapon2">Weapon2</option>
                    <option value="Weapon3">Weapon3</option>
                </select>
            </label>
        </div>
    );
};

export default SelectBoxAbility;
