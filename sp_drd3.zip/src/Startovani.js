import React, {useEffect, useState} from 'react';
import './App.css';

export default function Startovani({ setPristup }) {
    const [vybranySoubor, setVybranySoubor] = useState(null);
    const [chyba, setChyba] = useState(null);

    async function updatePicture(newName, race, sex, name, profession, level, strength, dexterity, endurance, intelligence, charisma,
                                 health, mags, gold, silver, cooper) {
        try {
            const response = await fetch('http://localhost:5001/Startovani', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    picture: newName,
                    race: race,
                    sex: sex,
                    name: name,
                    profession: profession,
                    level: level,

                    strength: strength,
                    dexterity: dexterity,
                    endurance: endurance,
                    intelligence: intelligence,
                    charisma: charisma,

                    health: health,
                    mags: mags,

                    gold: gold,
                    silver: silver,
                    cooper: cooper

                })
            });

            const data = await response.json();
            if (data.success) {
                console.log('Jméno úspěšně aktualizováno.');
            } else {
                console.error('Chyba při aktualizaci jména:', data.error);
            }
        } catch (error) {
            console.error('Chyba při komunikaci se serverem:', error);
        }
    }

    function handleFile(event) {
        const file = event.target.files[0];
        setVybranySoubor(file);
        console.log(file);
    }

    function handleUpload() {
        console.log(vybranySoubor);

        const formData = new FormData();
        formData.append('file', vybranySoubor);
        fetch('http://localhost:5000/Startovani', {
            method: "POST",
            body: formData,
        })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    console.log('Úspěch:', result);
                    updatePicture("profile_image.png", "", "", "", "", "1", "1", "1", "1", "1", "1",
                                  "0", "0", "0", "0", "0")
                } else {
                    setChyba('Chyba při nahrávání souboru.');
                    updatePicture("default_image.jpg", "", "", "", "", "1", "1", "1", "1", "1", "1",
                                  "0", "0", "0", "0", "0")
                }
            })
            .catch(error => {
                setChyba("Chyba při nahrávání souboru: " + error.message);
                console.error("Chyba:", error);
            });

    }

    return (
        <div style={{ display: 'flex' }}>
            <div className='new_character'>
                <form onSubmit={event => setPristup(0)}>
                    <h2 style={{ marginBottom: '14vh' }}>Create new character</h2>
                    <label className='new_character_picture_label' htmlFor="file-upload1">
                        Upload profile image (png, jpg):
                    </label>
                    <br />
                    <input
                        className='new_profile_image'
                        type="file"
                        id="file-upload1"
                        name="file-upload1"
                        onChange={handleFile}
                        accept=".png, .jpg"
                    />
                    <br />
                    {chyba && <p style={{ color: 'red' }}>{chyba}</p>}
                    <button className='new_character_button' type="submit" onClick={event => {handleUpload()}} /*onClick={event => setPristup(0)}*/>Create</button>
                </form>
            </div>
            <div className='mezirka_sirka'></div>
            <div className='line'></div>
            <div className='mezirka_sirka'></div>
            <div className='created_character'>
                <h2 style={{ marginBottom: '14vh' }}>Use created character</h2>
                <br />
                <input
                    className='exist_character_button'
                    type="button"
                    value='Play'
                    onClick={event => setPristup(0)}
                />
            </div>
        </div>
    );
}