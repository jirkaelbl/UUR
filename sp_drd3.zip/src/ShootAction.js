import * as React from 'react';
import './App.css';
import SelectBoxWeaponClose from "./SelectBoxWeaponClose";

export default function ShootAction({selectedWeaponLong, setSelectedWeaponLong}) {


    return (
        <div>



            <div>
                <div>
                    <div className='weapon_long_actioner' style={{display: 'flex'}}>
                        <SelectBoxWeaponClose selectedWeaponClose={selectedWeaponLong}
                                              setSelectedWeaponClose={setSelectedWeaponLong}/>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            UC:
                            <br/>
                            <input
                                className='weapon_long_UC'
                                value='10'
                                type="text"
                            />
                        </label>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            Utoc:
                            <br/>
                            <input
                                className='weapon_long_utoc'
                                value='+3'
                                type="text"
                            />
                        </label>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            Dexterity:
                            <br/>
                            <input
                                className='weapon_long_stat'
                                value='+3'
                                type="text"
                            />
                        </label>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            Throw:
                            <br/>
                            <input
                                className='weapon_long_throw'
                                placeholder='Throw'
                                type="number"
                            />
                        </label>
                    </div>
                    <div style={{marginTop: '3vh'}}>
                        <label style={{fontSize: '3.5vh'}}>
                            Distance:
                            <br/>
                            <input
                                className='weapon_long_distance'
                                value='10'
                                type="text"
                            />
                        </label>
                    </div>
                    <div style={{marginTop: '3vh'}}>
                        <label style={{fontSize: '5vh'}}>
                            Result:
                            <br/>
                            <input
                                className='weapon_long_result'
                                value='10'
                                type="text"
                            />
                        </label>
                    </div>
                </div>
            </div>


        </div>


    )

}