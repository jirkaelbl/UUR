import * as React from 'react';
import './App.css';
import SelectBoxWeaponClose from "./SelectBoxWeaponClose";

export default function CoverAction({selectedWeaponForCover, setSelectedWeaponForCover}) {

    return (
        <div>



            <div>
                <div>
                    <div className='weapon_cover_actioner' style={{display: 'flex'}}>
                        <SelectBoxWeaponClose selectedWeaponClose={selectedWeaponForCover}
                                              setSelectedWeaponClose={setSelectedWeaponForCover}/>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            OC of weapon:
                            <br/>
                            <input
                                className='weapon_cover_OC'
                                value='10'
                                type="text"
                            />
                        </label>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            OC of armor:
                            <br/>
                            <input
                                className='armor_OC'
                                value='+3'
                                type="text"
                            />
                        </label>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            Dexterity:
                            <br/>
                            <input
                                className='weapon_cover_stat'
                                value='+3'
                                type="text"
                            />
                        </label>

                        <div style={{width: '10vh'}}>

                        </div>

                        <label>
                            Throw:
                            <br/>
                            <input
                                className='cover_throw'
                                placeholder='Throw'
                                type="number"
                            />
                        </label>
                    </div>
                    <div style={{marginTop: '10vh'}}>
                        <label style={{fontSize: '5vh'}}>
                            Result:
                            <br/>
                            <input
                                className='cover_result'
                                value='10'
                                type="text"
                            />
                        </label>
                    </div>
                </div>
            </div>


        </div>


    )

}