import * as React from 'react';
import './App.css';

import SelectBoxWeaponClose from './SelectBoxWeaponClose';


export default function AttackAction({selectedWeaponClose, setSelectedWeaponClose}) {


    return (
        <div>



                <div>
                    <div>
                        <div className='weapon_close_actioner' style={{display: 'flex'}}>
                            <SelectBoxWeaponClose selectedWeaponClose={selectedWeaponClose}
                                                  setSelectedWeaponClose={setSelectedWeaponClose}/>

                            <div style={{width: '10vh'}}>

                            </div>

                            <label>
                                UC:
                                <br/>
                                <input
                                    className='weapon_close_UC'
                                    value='10'
                                    type="text"
                                />
                            </label>

                            <div style={{width: '10vh'}}>

                            </div>

                            <label>
                                Utoc:
                                <br/>
                                <input
                                    className='weapon_close_utoc'
                                    value='+3'
                                    type="text"
                                />
                            </label>

                            <div style={{width: '10vh'}}>

                            </div>

                            <label>
                                Stregth:
                                <br/>
                                <input
                                    className='weapon_close_stat'
                                    value='+3'
                                    type="text"
                                />
                            </label>

                            <div style={{width: '10vh'}}>

                            </div>

                            <label>
                                Throw:
                                <br/>
                                <input
                                    className='weapon_close_throw'
                                    placeholder='Throw'
                                    type="number"
                                />
                            </label>
                        </div>
                        <div style={{marginTop: '10vh'}}>
                            <label style={{fontSize: '5vh'}}>
                                Result:
                                <br/>
                                <input
                                    className='weapon_close_result'
                                    value='10'
                                    type="text"
                                />
                            </label>
                        </div>
                    </div>
                </div>


        </div>


    )

}