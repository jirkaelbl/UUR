const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5002;

app.use(bodyParser.json());
app.use(cors());

app.post('/Postava', (req, res) => {
    const { name, race, sex, profession, level, health, mags,
            strength, dexterity, endurance, intelligence, charisma} = req.body; // Předpokládáme, že nové údaje přijdou v těle požadavku

    // Cesta k JSON souboru
    const filePath = path.join(__dirname, 'src/data', 'data.json');

    // Načtení JSON souboru
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, error: 'Failed to read file' });
        }

        // Parsuje data z JSON souboru do objektu
        const jsonData = JSON.parse(data);

        // Aktualizace dat
        if (name !== undefined) jsonData.name = name;
        if (race !== undefined) jsonData.race = race;
        if (sex !== undefined) jsonData.sex = sex;
        if (profession !== undefined) jsonData.profession = profession;
        if (level !== undefined) jsonData.level = level;
        if (health !== undefined) jsonData.health = health;
        if (mags !== undefined) jsonData.mags = mags;
        if (strength !== undefined) jsonData.stats.strength = strength;
        if (dexterity !== undefined) jsonData.stats.dexterity = dexterity;
        if (endurance !== undefined) jsonData.stats.endurance = endurance;
        if (intelligence !== undefined) jsonData.stats.intelligence = intelligence;
        if (charisma !== undefined) jsonData.stats.charisma = charisma;




        // Znovu uložení aktualizovaných dat zpět do JSON souboru
        fs.writeFile(filePath, JSON.stringify(jsonData, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ success: false, error: 'Failed to write file' });
            }
            res.json({ success: true });
        });
    });
});

app.listen(PORT, () => {
    console.log(`Server běží na portu ${PORT}`);
});
